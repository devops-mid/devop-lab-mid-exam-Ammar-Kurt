#!/bin/bash
echo "Running tests..."
# TODO: Add commands to run unit and integration tests
